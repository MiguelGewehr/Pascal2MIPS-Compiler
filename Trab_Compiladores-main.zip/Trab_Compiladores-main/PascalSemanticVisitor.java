import parser.*;
import java.util.*;
import org.antlr.v4.runtime.tree.TerminalNode;

public class PascalSemanticVisitor extends PascalParserBaseVisitor<Void> {

    private final Map<String, Map<String, Simbolo>> scopes = new HashMap<>();
    private String currentScope = "global";
    private final Set<String> stringLiterals = new HashSet<>();
    private boolean hasErrors = false;

    public PascalSemanticVisitor() {
        scopes.put("global", new HashMap<>());
    }

    @Override
    public Void visitVarDeclaration(PascalParser.VarDeclarationContext ctx) {
        String tipoStr = ctx.typeDenoter().getText();
        boolean isVetor = tipoStr.toLowerCase().contains("array");
        TipoSimbolo tipo = converterTipo(tipoStr);

        for (TerminalNode id : ctx.identifierList().IDENTIFIER()) {
            String nome = id.getText();
            CategoriaSimbolo categoria = isVetor ? CategoriaSimbolo.VETOR : CategoriaSimbolo.VARIAVEL;
            Simbolo simbolo = new Simbolo(nome, tipo, categoria, id.getSymbol().getLine());
            scopes.get(currentScope).put(nome, simbolo);
        }

        return super.visitVarDeclaration(ctx);
    }

    @Override
    public Void visitFunctionDeclaration(PascalParser.FunctionDeclarationContext ctx) {
        String nomeFuncao = ctx.getChild(1).getText();
        String tipoStr = "desconhecido";

        for (int i = 0; i < ctx.getChildCount(); i++) {
            if (ctx.getChild(i).getText().equals(":") && i + 1 < ctx.getChildCount()) {
                tipoStr = ctx.getChild(i + 1).getText();
                break;
            }
        }

        TipoSimbolo tipo = converterTipo(tipoStr);
        Simbolo simboloFuncao = new Simbolo(nomeFuncao, tipo, CategoriaSimbolo.FUNCAO, ctx.getStart().getLine());
        scopes.get("global").put(nomeFuncao, simboloFuncao);

        scopes.put(nomeFuncao, new HashMap<>());
        String escopoAnterior = currentScope;
        currentScope = nomeFuncao;

        super.visitFunctionDeclaration(ctx);
        currentScope = escopoAnterior;
        return null;
    }

    @Override
    public Void visitProcedureDeclaration(PascalParser.ProcedureDeclarationContext ctx) {
        String nomeProc = ctx.getChild(1).getText();
        Simbolo simboloProc = new Simbolo(nomeProc, TipoSimbolo.DESCONHECIDO, CategoriaSimbolo.PROCEDIMENTO, ctx.getStart().getLine());
        scopes.get("global").put(nomeProc, simboloProc);

        scopes.put(nomeProc, new HashMap<>());
        String escopoAnterior = currentScope;
        currentScope = nomeProc;

        super.visitProcedureDeclaration(ctx);
        currentScope = escopoAnterior;
        return null;
    }

    @Override
    public Void visitFormalParameterSection(PascalParser.FormalParameterSectionContext ctx) {
        String tipoStr = ctx.IDENTIFIER().getText();
        TipoSimbolo tipo = converterTipo(tipoStr);

        for (TerminalNode id : ctx.identifierList().IDENTIFIER()) {
            String nome = id.getText();
            Simbolo simbolo = new Simbolo(nome, tipo, CategoriaSimbolo.PARAMETRO, id.getSymbol().getLine());
            scopes.get(currentScope).put(nome, simbolo);
        }

        return null;
    }

    @Override
    public Void visitAssignmentStatement(PascalParser.AssignmentStatementContext ctx) {
        String varName = ctx.variable().IDENTIFIER().getText();
        Simbolo simbolo = findSymbol(varName);

        if (simbolo == null) {
            System.err.println("Erro: variável '" + varName + "' não declarada");
            hasErrors = true;
        } else if (simbolo.categoria == CategoriaSimbolo.CONSTANTE) {
            System.err.println("Erro: tentativa de modificar constante '" + varName + "'");
            hasErrors = true;
        }

        visit(ctx.expression());
        return null;
    }

    private Simbolo findSymbol(String name) {
        Simbolo simbolo = scopes.get(currentScope).get(name);
        if (simbolo != null) return simbolo;
        return scopes.get("global").get(name);
    }

    @Override
    public Void visitProcedureCall(PascalParser.ProcedureCallContext ctx) {
        String procName = ctx.IDENTIFIER().getText();

        if (procName.equals("read") || procName.equals("readln") ||
            procName.equals("write") || procName.equals("writeln")) {
            if (ctx.expressionList() != null) {
                for (var exprItem : ctx.expressionList().expressionItem()) {
                    visit(exprItem);
                }
            }
            return null;
        }

        Simbolo s = scopes.get("global").get(procName);
        if (s == null || 
            (s.categoria != CategoriaSimbolo.PROCEDIMENTO && s.categoria != CategoriaSimbolo.FUNCAO)) {
            System.err.println("Erro: chamada para procedimento ou função não declarado: " + procName);
            hasErrors = true;
        }

        return null;
    }

    @Override
    public Void visitConstDefinition(PascalParser.ConstDefinitionContext ctx) {
        String nome = ctx.IDENTIFIER().getText();
        TipoSimbolo tipo = inferirTipoConstante(ctx.constant());
        Simbolo simbolo = new Simbolo(nome, tipo, CategoriaSimbolo.CONSTANTE, ctx.getStart().getLine());
        scopes.get(currentScope).put(nome, simbolo);
        return super.visitConstDefinition(ctx);
    }

    private TipoSimbolo inferirTipoConstante(PascalParser.ConstantContext ctx) {
        if (ctx.signedNumber() != null) {
            if (ctx.signedNumber().REAL() != null) return TipoSimbolo.REAL;
            return TipoSimbolo.INTEGER;
        }
        if (ctx.CHARACTER() != null) return TipoSimbolo.CHAR;
        if (ctx.STRING() != null) return TipoSimbolo.STRING;
        if (ctx.IDENTIFIER() != null) return TipoSimbolo.IDENTIFIER;
        return TipoSimbolo.DESCONHECIDO;
    }

    private TipoSimbolo converterTipo(String tipoStr) {
        tipoStr = tipoStr.toLowerCase();
        return switch (tipoStr) {
            case "integer" -> TipoSimbolo.INTEGER;
            case "real" -> TipoSimbolo.REAL;
            case "char" -> TipoSimbolo.CHAR;
            case "string" -> TipoSimbolo.STRING;
            case "boolean" -> TipoSimbolo.BOOLEAN;
            default -> tipoStr.contains("array") ? TipoSimbolo.ARRAY : TipoSimbolo.DESCONHECIDO;
        };
    }

    @Override
    public Void visitFactor(PascalParser.FactorContext ctx) {
        if (ctx.STRING() != null) {
            stringLiterals.add(ctx.STRING().getText());
        }
        return super.visitFactor(ctx);
    }

    public void printAnalysis() {
        System.out.println("\n=== Análise Semântica ===");
        System.out.println("Símbolos declarados por escopo:");
        scopes.forEach((escopo, tabela) -> {
            System.out.println("\nEscopo: " + escopo);
            tabela.forEach((nome, simbolo) -> {
                System.out.printf("  %s : %s (%s, linha: %d)\n",
    simbolo.nome, simbolo.tipo.toString(), simbolo.categoria.toString(), simbolo.linha);

            });
        });

        System.out.println("\nStatus: " + (hasErrors ? "ERROS ENCONTRADOS" : "OK"));
    }

    public boolean hasErrors() {
        return hasErrors;
    }
}
