public enum CategoriaSimbolo {
    VARIAVEL,
    VETOR,
    FUNCAO,
    PROCEDIMENTO,
    PARAMETRO,
    CONSTANTE
}